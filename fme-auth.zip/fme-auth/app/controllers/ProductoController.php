<?php
/* =========================
   ALTA / EDICIÓN / ELIMINACIÓN PRODUCTO (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'productos') {

  $form = $_POST['form'] ?? '';

  if ($form === 'add_producto') {
    $nombre_prod  = trim($_POST['nombre_producto'] ?? '');
    $precio_prod  = trim($_POST['precio_producto'] ?? '');
    $stock_prod   = trim($_POST['stock_producto'] ?? '');
    $id_categoria = $_POST['id_categoria'] ?? '';
    $id_proveedor = $_POST['id_proveedor'] ?? '';

    $errores = [];
    if ($nombre_prod === '')                               $errores[] = 'Falta el nombre del producto.';
    if ($precio_prod === '')                               $errores[] = 'Falta el precio del producto.';
    if ($stock_prod === '')                                $errores[] = 'Falta el stock del producto.';
    if (!is_numeric($precio_prod) || $precio_prod < 0)     $errores[] = 'El precio no es válido.';
    if (!ctype_digit($stock_prod) || (int)$stock_prod < 0) $errores[] = 'El stock no es válido.';
    if ($id_categoria === '')                              $errores[] = 'Debe seleccionar una categoría.';
    if ($id_proveedor === '')                              $errores[] = 'Debe seleccionar un proveedor.';

    if ($errores) {
      flash('error', implode(' ', $errores));
      header('Location: index.php?mod=productos&action=add');
      exit;
    }

    try {
      $stmt = $pdo->prepare('INSERT INTO Producto (nombre_producto, precio_producto, stock_producto, id_categoria, id_proveedor)
                             VALUES (?,?,?,?,?)');
      $stmt->execute([
        $nombre_prod,
        (float)$precio_prod,
        (int)$stock_prod,
        (int)$id_categoria,
        (int)$id_proveedor
      ]);

      flash('success', 'El producto se ha agregado correctamente.');
      header('Location: index.php?mod=productos');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se pudo agregar el producto. Inténtalo nuevamente.');
      header('Location: index.php?mod=productos&action=add');
      exit;
    }

  } elseif ($form === 'edit_producto') {

    $id_producto  = (int)($_POST['id_producto'] ?? 0);
    $nombre_prod  = trim($_POST['nombre_producto'] ?? '');
    $precio_prod  = trim($_POST['precio_producto'] ?? '');
    $stock_prod   = trim($_POST['stock_producto'] ?? '');
    $id_categoria = $_POST['id_categoria'] ?? '';
    $id_proveedor = $_POST['id_proveedor'] ?? '';

    $errores = [];
    if ($id_producto <= 0)                                 $errores[] = 'ID de producto inválido.';
    if ($nombre_prod === '')                               $errores[] = 'Falta el nombre del producto.';
    if ($precio_prod === '')                               $errores[] = 'Falta el precio del producto.';
    if ($stock_prod === '')                                $errores[] = 'Falta el stock del producto.';
    if (!is_numeric($precio_prod) || $precio_prod < 0)     $errores[] = 'El precio no es válido.';
    if (!ctype_digit($stock_prod) || (int)$stock_prod < 0) $errores[] = 'El stock no es válido.';
    if ($id_categoria === '')                              $errores[] = 'Debe seleccionar una categoría.';
    if ($id_proveedor === '')                              $errores[] = 'Debe seleccionar un proveedor.';

    if ($errores) {
      flash('error', implode(' ', $errores));
      header('Location: index.php?mod=productos&action=edit&id=' . $id_producto);
      exit;
    }

    try {
      $stmt = $pdo->prepare('UPDATE Producto
                             SET nombre_producto = ?, precio_producto = ?, stock_producto = ?,
                                 id_categoria = ?, id_proveedor = ?
                             WHERE id_producto = ?');
      $stmt->execute([
        $nombre_prod,
        (float)$precio_prod,
        (int)$stock_prod,
        (int)$id_categoria,
        (int)$id_proveedor,
        $id_producto
      ]);

      flash('success', 'El producto se ha actualizado correctamente.');
      header('Location: index.php?mod=productos');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se pudo actualizar el producto.');
      header('Location: index.php?mod=productos&action=edit&id=' . $id_producto);
      exit;
    }

  } elseif ($form === 'delete_producto') {

    $id_producto = (int)($_POST['id_producto'] ?? 0);

    if ($id_producto <= 0) {
      flash('error', 'ID de producto inválido.');
      header('Location: index.php?mod=productos');
      exit;
    }

    try {
      $stmt = $pdo->prepare('DELETE FROM Producto WHERE id_producto = ?');
      $stmt->execute([$id_producto]);

      if ($stmt->rowCount() > 0) {
        flash('success', 'El producto se eliminó correctamente.');
      } else {
        flash('error', 'No se encontró el producto a eliminar.');
      }

      header('Location: index.php?mod=productos');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se puede eliminar el producto porque está relacionado con otros registros.');
      header('Location: index.php?mod=productos');
      exit;
    }
  }
}
