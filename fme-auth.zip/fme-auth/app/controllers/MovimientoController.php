<?php
/* =========================
   REGISTRAR MOVIMIENTO (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'movimientos') {

  $form = $_POST['form'] ?? '';

  if ($form === 'add_movimiento') {

    $id_producto = (int)($_POST['id_producto'] ?? 0);
    $id_tipo     = (int)($_POST['id_tipo'] ?? 0);
    $id_motivo   = (int)($_POST['id_motivo'] ?? 0);
    $cantidad    = trim($_POST['cantidad_movimiento'] ?? '');

    $errores = [];
    if ($id_producto <= 0)                  $errores[] = 'Debe seleccionar un producto.';
    if ($id_tipo <= 0)                      $errores[] = 'Debe seleccionar un tipo de movimiento.';
    if ($id_motivo <= 0)                    $errores[] = 'Debe seleccionar un motivo.';
    if ($cantidad === '' || !ctype_digit($cantidad) || (int)$cantidad <= 0) {
      $errores[] = 'La cantidad debe ser un entero positivo.';
    }

    if ($errores) {
      flash('error', implode(' ', $errores));
      header('Location: index.php?mod=movimientos&action=add');
      exit;
    }

    $cantidadInt = (int)$cantidad;

    try {
      $pdo->beginTransaction();

      // Traer stock actual del producto
      $stmt = $pdo->prepare("SELECT stock_producto FROM Producto WHERE id_producto = ?");
      $stmt->execute([$id_producto]);
      $prod = $stmt->fetch();

      if (!$prod) {
        $pdo->rollBack();
        flash('error', 'Producto no encontrado.');
        header('Location: index.php?mod=movimientos&action=add');
        exit;
      }

      $stockActual = (int)$prod['stock_producto'];

      // Convención:
      // id_tipo = 1 => Entrada (suma stock)
      // id_tipo = 2 => Salida (resta stock)
      $delta = 0;

      if ($id_tipo === 1) {
        $delta = $cantidadInt; // Entrada
      } elseif ($id_tipo === 2) {
        if ($stockActual < $cantidadInt) {
          $pdo->rollBack();
          flash('error', 'No hay stock suficiente para realizar la salida.');
          header('Location: index.php?mod=movimientos&action=add');
          exit;
        }
        $delta = -$cantidadInt;
      } else {
        $delta = 0; // otros tipos sin impacto en stock
      }

      // Insertar movimiento
      $stmt = $pdo->prepare("INSERT INTO Movimiento
        (cantidad_movimiento, fecha_movimiento, id_producto, id_usuario, id_tipo, id_motivo)
        VALUES (?, NOW(), ?, ?, ?, ?)");
      $stmt->execute([
        $cantidadInt,
        $id_producto,
        $userId,
        $id_tipo,
        $id_motivo
      ]);

      // Actualizar stock si corresponde
      if ($delta !== 0) {
        $stmt = $pdo->prepare("UPDATE Producto SET stock_producto = stock_producto + ? WHERE id_producto = ?");
        $stmt->execute([$delta, $id_producto]);
      }

      $pdo->commit();

      flash('success', 'El movimiento se registró correctamente.');
      header('Location: index.php?mod=movimientos');
      exit;

    } catch (Throwable $e) {
      $pdo->rollBack();
      flash('error', 'No se pudo registrar el movimiento.');
      header('Location: index.php?mod=movimientos&action=add');
      exit;
    }
  }
}
