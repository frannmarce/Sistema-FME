<?php
/* =========================
   FORM PERFIL USUARIO (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'config_usuario') {

  $nombre     = trim($_POST['nombre_persona'] ?? '');
  $apellido   = trim($_POST['apellido_persona'] ?? '');
  $cuil       = trim($_POST['CUIL_persona'] ?? '');
  $telefono   = trim($_POST['telefono_persona'] ?? '');
  $pais       = trim($_POST['nombre_pais'] ?? '');
  $ciudad     = trim($_POST['nombre_ciudad'] ?? '');
  $direccion  = trim($_POST['num_direccion'] ?? '');

  $errores = [];
  if ($nombre === '')    $errores[] = 'Falta el nombre.';
  if ($apellido === '')  $errores[] = 'Falta el apellido.';
  if ($cuil === '')      $errores[] = 'Falta el CUIL.';
  if ($pais === '')      $errores[] = 'Falta el país.';
  if ($ciudad === '')    $errores[] = 'Falta la ciudad.';
  if ($direccion === '') $errores[] = 'Falta la dirección.';

  if ($errores) {
    flash('error', implode(' ', $errores));
    header('Location: index.php?mod=config_usuario');
    exit;
  }

  try {
    $pdo->beginTransaction();

    // Dirección
    $stmt = $pdo->prepare('INSERT INTO Direccion (nombre_pais, nombre_ciudad, num_direccion) VALUES (?,?,?)');
    $stmt->execute([$pais, $ciudad, $direccion]);
    $id_direccion = (int)$pdo->lastInsertId();

    // Persona
    $stmt = $pdo->prepare('INSERT INTO Persona (nombre_persona, apellido_persona, CUIL_persona, telefono_persona, id_direccion)
                           VALUES (?,?,?,?,?)');
    $stmt->execute([$nombre, $apellido, $cuil, $telefono ?: null, $id_direccion]);
    $id_persona = (int)$pdo->lastInsertId();

    // Usuario
    $stmt = $pdo->prepare('UPDATE Usuario SET id_persona = ? WHERE id_usuario = ?');
    $stmt->execute([$id_persona, $userId]);

    $pdo->commit();
    $_SESSION['needs_profile'] = false;

    flash('success', 'La información se ha guardado con éxito.');
    header('Location: index.php');
    exit;

  } catch (Throwable $e) {
    $pdo->rollBack();
    flash('error', 'No se pudo guardar la información.');
    header('Location: index.php?mod=config_usuario');
    exit;
  }
}
