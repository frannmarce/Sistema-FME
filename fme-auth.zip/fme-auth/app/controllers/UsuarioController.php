<?php
/* =========================
   EDICIÓN DE USUARIO (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'usuarios') {

  $form = $_POST['form'] ?? '';

  if ($form === 'edit_usuario') {

    if (!isset($modulosPermitidosConArchivo['usuarios'])) {
      flash('error', 'No tienes permiso para editar usuarios.');
      header('Location: index.php');
      exit;
    }

    $id_usuario     = (int)($_POST['id_usuario'] ?? 0);
    $nombre_usuario = trim($_POST['nombre_usuario'] ?? '');
    $correo_usuario = trim($_POST['correo_usuario'] ?? '');
    $cuil_persona   = trim($_POST['CUIL_persona'] ?? '');
    $id_rol         = (int)($_POST['id_rol'] ?? 0);

    $errores = [];

    if ($id_usuario <= 0) {
      $errores[] = 'ID de usuario inválido.';
    }

    if ($nombre_usuario === '') {
      $errores[] = 'Debe ingresar un nombre de usuario.';
    }

    if ($correo_usuario === '') {
      $errores[] = 'Debe ingresar un correo.';
    }

    if ($correo_usuario !== '' && !filter_var($correo_usuario, FILTER_VALIDATE_EMAIL)) {
      $errores[] = 'Correo inválido.';
    }

    if ($id_rol <= 0) {
      $errores[] = 'Debe seleccionar un perfil válido.';
    }

    if (!$errores) {
      $stmt = $pdo->prepare("
        SELECT id_rol
        FROM Tipo_Rol
        WHERE id_rol = ?
          AND activo = 1
        LIMIT 1
      ");
      $stmt->execute([$id_rol]);

      if (!$stmt->fetch()) {
        $errores[] = 'El perfil seleccionado no existe o está inactivo.';
      }
    }

    /*
      Protección del único administrador:
      si el usuario editado es el único administrador activo del sistema,
      no se permite cambiarlo a otro perfil porque el sistema quedaría
      sin una cuenta con permisos administrativos.
    */
    $rolActualUsuario = 0;
    if (!$errores) {
      $stmt = $pdo->prepare('SELECT id_rol FROM Usuario WHERE id_usuario = ? LIMIT 1');
      $stmt->execute([$id_usuario]);
      $rolActualUsuario = (int)($stmt->fetchColumn() ?: 0);

      if ($rolActualUsuario === 1 && $id_rol !== 1) {
        $stmt = $pdo->query('SELECT COUNT(*) FROM Usuario WHERE id_rol = 1');
        $cantidadAdministradores = (int)$stmt->fetchColumn();

        if ($cantidadAdministradores <= 1) {
          $errores[] = 'No se puede cambiar el perfil del único administrador existente.';
        }
      }
    }

    /*
      Exclusión del propio usuario al editar:
      se valida que no exista OTRO usuario con el mismo usuario/correo/CUIL.
      El usuario que estoy editando queda excluido con AND id_usuario <> ?.
    */

    if (!$errores) {
      $stmt = $pdo->prepare("
        SELECT id_usuario
        FROM Usuario
        WHERE nombre_usuario = ?
        AND id_usuario <> ?
        LIMIT 1
      ");
      $stmt->execute([$nombre_usuario, $id_usuario]);

      if ($stmt->fetch()) {
        $errores[] = 'Ese nombre de usuario ya está en uso.';
      }
    }

    if (!$errores) {
      $stmt = $pdo->prepare("
        SELECT id_usuario
        FROM Usuario
        WHERE correo_usuario = ?
        AND id_usuario <> ?
        LIMIT 1
      ");
      $stmt->execute([$correo_usuario, $id_usuario]);

      if ($stmt->fetch()) {
        $errores[] = 'Ese correo ya está en uso.';
      }
    }

    if (!$errores && $cuil_persona !== '') {
      $stmt = $pdo->prepare("
        SELECT p.id_persona
        FROM Persona p
        INNER JOIN Usuario u ON p.id_persona = u.id_persona
        WHERE p.CUIL_persona = ?
        AND u.id_usuario <> ?
        LIMIT 1
      ");
      $stmt->execute([$cuil_persona, $id_usuario]);

      if ($stmt->fetch()) {
        $errores[] = 'Ese CUIL/DNI ya está registrado.';
      }
    }

    if ($errores) {
      flash('error', implode(' ', $errores));
      header('Location: index.php?mod=usuarios&action=edit&id=' . $id_usuario);
      exit;
    }

    try {
      $pdo->beginTransaction();

      $stmt = $pdo->prepare("
        UPDATE Usuario
        SET nombre_usuario = ?,
            correo_usuario = ?,
            id_rol = ?
        WHERE id_usuario = ?
      ");

      $stmt->execute([
        $nombre_usuario,
        $correo_usuario,
        $id_rol,
        $id_usuario
      ]);

      if ($cuil_persona !== '') {
        $stmt = $pdo->prepare("
          UPDATE Persona p
          INNER JOIN Usuario u ON p.id_persona = u.id_persona
          SET p.CUIL_persona = ?
          WHERE u.id_usuario = ?
        ");

        $stmt->execute([
          $cuil_persona,
          $id_usuario
        ]);
      }

      $pdo->commit();

      /*
        Seguridad de sesión:
        si el administrador edita su propio usuario y cambia su perfil,
        se actualiza la sesión inmediatamente. Así no conserva permisos
        anteriores hasta cerrar e iniciar sesión nuevamente.
      */
      if ($id_usuario === $userId) {
        $_SESSION['auth_user'] = $nombre_usuario;
        $_SESSION['auth_rol'] = $id_rol;

        if ($rolActualUsuario !== $id_rol) {
          flash('success', 'Tu perfil fue actualizado. Los permisos se recalcularon correctamente.');
          header('Location: index.php');
          exit;
        }
      }

      flash('success', 'Usuario actualizado correctamente.');
      header('Location: index.php?mod=usuarios');
      exit;

    } catch (Throwable $e) {
      $pdo->rollBack();

      flash('error', 'No se pudo actualizar el usuario.');
      header('Location: index.php?mod=usuarios&action=edit&id=' . $id_usuario);
      exit;
    }
  }
}
