<?php
/* =========================
   ABM DE PERFILES / ROLES (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'perfiles') {

  if (!isset($modulosPermitidosConArchivo['perfiles'])) {
    flash('error', 'No tienes permiso para administrar perfiles.');
    header('Location: index.php');
    exit;
  }

  $form = $_POST['form'] ?? '';

  if ($form === 'add_perfil' || $form === 'edit_perfil') {
    $id_rol = (int)($_POST['id_rol'] ?? 0);
    $nombre_rol = trim($_POST['nombre_rol'] ?? '');
    $descripcion_rol = trim($_POST['descripcion_rol'] ?? '');

    $errores = [];

    if ($form === 'edit_perfil' && $id_rol <= 0) {
      $errores[] = 'ID de perfil inválido.';
    }

    if ($nombre_rol === '') {
      $errores[] = 'Debe ingresar el nombre del perfil.';
    }

    if (mb_strlen($nombre_rol) > 50) {
      $errores[] = 'El nombre del perfil no puede superar los 50 caracteres.';
    }

    if (mb_strlen($descripcion_rol) > 100) {
      $errores[] = 'La descripción no puede superar los 100 caracteres.';
    }

    if (!$errores) {
      $sql = 'SELECT id_rol FROM Tipo_Rol WHERE nombre_rol = ?';
      $params = [$nombre_rol];

      if ($form === 'edit_perfil') {
        $sql .= ' AND id_rol <> ?';
        $params[] = $id_rol;
      }

      $sql .= ' LIMIT 1';
      $stmt = $pdo->prepare($sql);
      $stmt->execute($params);

      if ($stmt->fetch()) {
        $errores[] = 'Ya existe un perfil con ese nombre.';
      }
    }

    if ($errores) {
      flash('error', implode(' ', $errores));
      $url = $form === 'edit_perfil'
        ? 'index.php?mod=perfiles&action=edit&id=' . $id_rol
        : 'index.php?mod=perfiles&action=add';
      header('Location: ' . $url);
      exit;
    }

    try {
      $pdo->beginTransaction();

      if ($form === 'add_perfil') {
        $stmt = $pdo->prepare('INSERT INTO Tipo_Rol (nombre_rol, descripcion_rol, activo) VALUES (?, ?, 1)');
        $stmt->execute([$nombre_rol, $descripcion_rol ?: null]);
        $id_rol = (int)$pdo->lastInsertId();
        flash('success', 'Perfil creado correctamente. Ahora puedes asignarle módulos.');
      } else {
        $stmt = $pdo->prepare('UPDATE Tipo_Rol SET nombre_rol = ?, descripcion_rol = ? WHERE id_rol = ?');
        $stmt->execute([$nombre_rol, $descripcion_rol ?: null, $id_rol]);

        $modulosSeleccionados = $_POST['modulos'] ?? [];
        if (!is_array($modulosSeleccionados)) {
          $modulosSeleccionados = [];
        }

        $modulosValidos = [];
        foreach ($modulosSeleccionados as $idModulo) {
          $idModulo = (int)$idModulo;
          if ($idModulo > 0) {
            $modulosValidos[] = $idModulo;
          }
        }
        $modulosValidos = array_values(array_unique($modulosValidos));

        $stmt = $pdo->prepare('DELETE FROM Rol_Modulo WHERE id_rol = ?');
        $stmt->execute([$id_rol]);

        if ($modulosValidos) {
          $stmt = $pdo->prepare('INSERT INTO Rol_Modulo (id_rol, id_modulo) VALUES (?, ?)');
          foreach ($modulosValidos as $idModulo) {
            $stmt->execute([$id_rol, $idModulo]);
          }
        }

        flash('success', 'Perfil actualizado correctamente.');
      }

      $pdo->commit();
      header('Location: index.php?mod=perfiles');
      exit;

    } catch (Throwable $e) {
      if ($pdo->inTransaction()) {
        $pdo->rollBack();
      }
      flash('error', 'No se pudo guardar el perfil. Verifica que existan las tablas Modulo y Rol_Modulo.');
      header('Location: index.php?mod=perfiles');
      exit;
    }
  }


  if ($form === 'activate_perfil') {
    $id_rol = (int)($_POST['id_rol'] ?? 0);

    if ($id_rol <= 0) {
      flash('error', 'ID de perfil inválido.');
      header('Location: index.php?mod=perfiles');
      exit;
    }

    try {
      $stmt = $pdo->prepare('UPDATE Tipo_Rol SET activo = 1 WHERE id_rol = ?');
      $stmt->execute([$id_rol]);

      flash('success', 'Perfil activado correctamente.');
      header('Location: index.php?mod=perfiles');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se pudo activar el perfil.');
      header('Location: index.php?mod=perfiles');
      exit;
    }
  }

  if ($form === 'delete_perfil') {
    $id_rol = (int)($_POST['id_rol'] ?? 0);

    if ($id_rol <= 0) {
      flash('error', 'ID de perfil inválido.');
      header('Location: index.php?mod=perfiles');
      exit;
    }

    if ($id_rol === 1) {
      flash('error', 'No se puede desactivar el perfil Administrador principal.');
      header('Location: index.php?mod=perfiles');
      exit;
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM Usuario WHERE id_rol = ?');
    $stmt->execute([$id_rol]);
    $usuariosConPerfil = (int)$stmt->fetchColumn();

    if ($usuariosConPerfil > 0) {
      flash('error', 'No se puede desactivar el perfil porque hay usuarios asignados.');
      header('Location: index.php?mod=perfiles');
      exit;
    }

    try {
      $stmt = $pdo->prepare('UPDATE Tipo_Rol SET activo = 0 WHERE id_rol = ?');
      $stmt->execute([$id_rol]);

      flash('success', 'Perfil desactivado correctamente.');
      header('Location: index.php?mod=perfiles');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se pudo desactivar el perfil.');
      header('Location: index.php?mod=perfiles');
      exit;
    }
  }
}
