<?php
// app/core/bootstrap.php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../../test.php';
require_once __DIR__ . '/../../db.php';

/* =========================
   SEGURIDAD / AUTENTICACIÓN
   ========================= */
if (!isset($_SESSION['auth_id'])) {
  header('Location: login.php');
  exit;
}

$usuario = $_SESSION['auth_user'] ?? 'Usuario';
$rolId   = (int)($_SESSION['auth_rol'] ?? 2); // id_rol = perfil del usuario
$userId  = (int)$_SESSION['auth_id'];

$modActual = $_GET['mod'] ?? 'panel';
$action    = $_GET['action'] ?? 'list';

// Nombre del perfil actual para mostrarlo en la interfaz.
$rolNombre = 'Operador';
try {
  $stmt = $pdo->prepare('SELECT nombre_rol FROM Tipo_Rol WHERE id_rol = ? LIMIT 1');
  $stmt->execute([$rolId]);
  $rolNombre = $stmt->fetchColumn() ?: $rolNombre;
} catch (Throwable $e) {
  $rolNombre = $rolId === 1 ? 'Administrador' : 'Operador';
}

/* =========================
   PERFIL COMPLETO (Persona/Dirección)
   ========================= */
$stmt = $pdo->prepare('SELECT id_persona FROM Usuario WHERE id_usuario = ?');
$stmt->execute([$userId]);
$row = $stmt->fetch();

$needsProfile = $row && is_null($row['id_persona']);
$_SESSION['needs_profile'] = $needsProfile;


/* =========================
   MÓDULOS PERMITIDOS POR PERFIL
   ========================= */
$modulos = [];
$modulosPermitidosPorCodigo = [];
$modulosPermitidosConArchivo = [];
$moduloActualInfo = null;

try {
  $stmt = $pdo->prepare("\n    SELECT m.id_modulo, m.codigo_modulo, m.nombre_modulo, m.icono_modulo,\n           m.url_modulo, m.archivo_modulo\n    FROM Rol_Modulo rm\n    INNER JOIN Modulo m ON rm.id_modulo = m.id_modulo\n    WHERE rm.id_rol = ?\n      AND m.activo = 1\n    ORDER BY m.id_modulo ASC\n  ");
  $stmt->execute([$rolId]);
  $modulosPerfil = $stmt->fetchAll(PDO::FETCH_ASSOC);

  foreach ($modulosPerfil as $m) {
    $codigo = $m['codigo_modulo'];
    $item = [
      'id' => $codigo,
      'icon' => $m['icono_modulo'] ?: '📌',
      'titulo' => $m['nombre_modulo'],
      'url' => $m['url_modulo'] ?: '#',
      'archivo' => $m['archivo_modulo']
    ];

    $modulos[] = $item;
    $modulosPermitidosPorCodigo[$codigo] = $item;

    if (!empty($m['archivo_modulo'])) {
      $modulosPermitidosConArchivo[$codigo] = $item;
    }
  }
} catch (Throwable $e) {
  // Si faltan las tablas Modulo/Rol_Modulo, se evita romper la página.
  $modulos = [
    ['id'=>'panel','icon'=>'🏠','titulo'=>'Panel de control','url'=>'index.php','archivo'=>'panel.php'],
    ['id'=>'config_usuario','icon'=>'👤','titulo'=>'Configuración de usuario','url'=>'index.php?mod=config_usuario','archivo'=>'config_usuario.php'],
    ['id'=>'productos','icon'=>'📦','titulo'=>'Productos','url'=>'index.php?mod=productos','archivo'=>'productos.php'],
    ['id'=>'movimientos','icon'=>'📑','titulo'=>'Movimientos','url'=>'index.php?mod=movimientos','archivo'=>'movimientos.php'],
  ];

  if ($rolId === 1) {
    $modulos[] = ['id'=>'usuarios','icon'=>'👥','titulo'=>'Gestión de usuarios','url'=>'index.php?mod=usuarios','archivo'=>'usuarios.php'];
    $modulos[] = ['id'=>'perfiles','icon'=>'🛡️','titulo'=>'Gestión de perfiles','url'=>'index.php?mod=perfiles','archivo'=>'perfiles.php'];
    $modulos[] = ['id'=>'ventas','icon'=>'🧾','titulo'=>'Facturación / Ventas','url'=>'index.php?mod=ventas','archivo'=>'ventas.php'];
  }

  foreach ($modulos as $m) {
    $modulosPermitidosPorCodigo[$m['id']] = $m;
    if (!empty($m['archivo'])) {
      $modulosPermitidosConArchivo[$m['id']] = $m;
    }
  }
}

// Módulos que siempre pueden abrirse mientras exista sesión.
$modulosSiemprePermitidos = ['panel', 'config_usuario'];
if (in_array($modActual, $modulosSiemprePermitidos, true)) {
  $moduloActualInfo = $modulosPermitidosConArchivo[$modActual] ?? [
    'id' => $modActual,
    'archivo' => $modActual === 'panel' ? 'panel.php' : 'config_usuario.php',
    'titulo' => $modActual === 'panel' ? 'Panel de control' : 'Configuración de usuario'
  ];
} else {
  $moduloActualInfo = $modulosPermitidosConArchivo[$modActual] ?? null;
}

// Validación central: si el perfil no tiene el módulo asignado, no puede entrar por URL manual.
if ($moduloActualInfo === null) {
  flash('error', 'No tienes permiso para acceder a ese módulo.');
  header('Location: index.php');
  exit;
}

require_once __DIR__ . '/../controllers/ConfigUsuarioController.php';
require_once __DIR__ . '/../controllers/UsuarioController.php';
require_once __DIR__ . '/../controllers/PerfilController.php';
require_once __DIR__ . '/../controllers/ProductoController.php';
require_once __DIR__ . '/../controllers/MovimientoController.php';
