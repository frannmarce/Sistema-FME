<?php
// app/core/bootstrap.php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../../test.php';
require_once __DIR__ . '/../../db.php';

/* =========================
   SEGURIDAD / AUTENTICACIÓN
   ========================= */
if (!isset($_SESSION['auth_id'])) {
  header('Location: login.php');
  exit;
}

$usuario = $_SESSION['auth_user'] ?? 'Usuario';
$rolId   = (int)($_SESSION['auth_rol'] ?? 2); // id_rol = perfil del usuario
$userId  = (int)$_SESSION['auth_id'];

$modActual = $_GET['mod'] ?? 'panel';
$action    = $_GET['action'] ?? 'list';

// Nombre del perfil actual para mostrarlo en la interfaz.
$rolNombre = 'Operador';
try {
  $stmt = $pdo->prepare('SELECT nombre_rol FROM Tipo_Rol WHERE id_rol = ? LIMIT 1');
  $stmt->execute([$rolId]);
  $rolNombre = $stmt->fetchColumn() ?: $rolNombre;
} catch (Throwable $e) {
  $rolNombre = $rolId === 1 ? 'Administrador' : 'Operador';
}

/* =========================
   PERFIL COMPLETO (Persona/Dirección)
   ========================= */
$stmt = $pdo->prepare('SELECT id_persona FROM Usuario WHERE id_usuario = ?');
$stmt->execute([$userId]);
$row = $stmt->fetch();

$needsProfile = $row && is_null($row['id_persona']);
$_SESSION['needs_profile'] = $needsProfile;


/* =========================
   MÓDULOS PERMITIDOS POR PERFIL
   ========================= */
$modulos = [];
$modulosPermitidosPorCodigo = [];
$modulosPermitidosConArchivo = [];
$moduloActualInfo = null;

try {
  $stmt = $pdo->prepare("\n    SELECT m.id_modulo, m.codigo_modulo, m.nombre_modulo, m.icono_modulo,\n           m.url_modulo, m.archivo_modulo\n    FROM Rol_Modulo rm\n    INNER JOIN Modulo m ON rm.id_modulo = m.id_modulo\n    WHERE rm.id_rol = ?\n      AND m.activo = 1\n    ORDER BY m.id_modulo ASC\n  ");
  $stmt->execute([$rolId]);
  $modulosPerfil = $stmt->fetchAll(PDO::FETCH_ASSOC);

  foreach ($modulosPerfil as $m) {
    $codigo = $m['codigo_modulo'];
    $item = [
      'id' => $codigo,
      'icon' => $m['icono_modulo'] ?: '📌',
      'titulo' => $m['nombre_modulo'],
      'url' => $m['url_modulo'] ?: '#',
      'archivo' => $m['archivo_modulo']
    ];

    $modulos[] = $item;
    $modulosPermitidosPorCodigo[$codigo] = $item;

    if (!empty($m['archivo_modulo'])) {
      $modulosPermitidosConArchivo[$codigo] = $item;
    }
  }
} catch (Throwable $e) {
  // Si faltan las tablas Modulo/Rol_Modulo, se evita romper la página.
  $modulos = [
    ['id'=>'panel','icon'=>'🏠','titulo'=>'Panel de control','url'=>'index.php','archivo'=>'panel.php'],
    ['id'=>'config_usuario','icon'=>'👤','titulo'=>'Configuración de usuario','url'=>'index.php?mod=config_usuario','archivo'=>'config_usuario.php'],
    ['id'=>'productos','icon'=>'📦','titulo'=>'Productos','url'=>'index.php?mod=productos','archivo'=>'productos.php'],
    ['id'=>'movimientos','icon'=>'📑','titulo'=>'Movimientos','url'=>'index.php?mod=movimientos','archivo'=>'movimientos.php'],
  ];

  if ($rolId === 1) {
    $modulos[] = ['id'=>'usuarios','icon'=>'👥','titulo'=>'Gestión de usuarios','url'=>'index.php?mod=usuarios','archivo'=>'usuarios.php'];
    $modulos[] = ['id'=>'perfiles','icon'=>'🛡️','titulo'=>'Gestión de perfiles','url'=>'index.php?mod=perfiles','archivo'=>'perfiles.php'];
    $modulos[] = ['id'=>'ventas','icon'=>'🧾','titulo'=>'Facturación / Ventas','url'=>'index.php?mod=ventas','archivo'=>'ventas.php'];
  }

  foreach ($modulos as $m) {
    $modulosPermitidosPorCodigo[$m['id']] = $m;
    if (!empty($m['archivo'])) {
      $modulosPermitidosConArchivo[$m['id']] = $m;
    }
  }
}

// Módulos que siempre pueden abrirse mientras exista sesión.
$modulosSiemprePermitidos = ['panel', 'config_usuario'];
if (in_array($modActual, $modulosSiemprePermitidos, true)) {
  $moduloActualInfo = $modulosPermitidosConArchivo[$modActual] ?? [
    'id' => $modActual,
    'archivo' => $modActual === 'panel' ? 'panel.php' : 'config_usuario.php',
    'titulo' => $modActual === 'panel' ? 'Panel de control' : 'Configuración de usuario'
  ];
} else {
  $moduloActualInfo = $modulosPermitidosConArchivo[$modActual] ?? null;
}

// Validación central: si el perfil no tiene el módulo asignado, no puede entrar por URL manual.
if ($moduloActualInfo === null) {
  flash('error', 'No tienes permiso para acceder a ese módulo.');
  header('Location: index.php');
  exit;
}

/* =========================
   FORM PERFIL USUARIO (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'config_usuario') {

  $nombre     = trim($_POST['nombre_persona'] ?? '');
  $apellido   = trim($_POST['apellido_persona'] ?? '');
  $cuil       = trim($_POST['CUIL_persona'] ?? '');
  $telefono   = trim($_POST['telefono_persona'] ?? '');
  $pais       = trim($_POST['nombre_pais'] ?? '');
  $ciudad     = trim($_POST['nombre_ciudad'] ?? '');
  $direccion  = trim($_POST['num_direccion'] ?? '');

  $errores = [];
  if ($nombre === '')    $errores[] = 'Falta el nombre.';
  if ($apellido === '')  $errores[] = 'Falta el apellido.';
  if ($cuil === '')      $errores[] = 'Falta el CUIL.';
  if ($pais === '')      $errores[] = 'Falta el país.';
  if ($ciudad === '')    $errores[] = 'Falta la ciudad.';
  if ($direccion === '') $errores[] = 'Falta la dirección.';

  if ($errores) {
    flash('error', implode(' ', $errores));
    header('Location: index.php?mod=config_usuario');
    exit;
  }

  try {
    $pdo->beginTransaction();

    // Dirección
    $stmt = $pdo->prepare('INSERT INTO Direccion (nombre_pais, nombre_ciudad, num_direccion) VALUES (?,?,?)');
    $stmt->execute([$pais, $ciudad, $direccion]);
    $id_direccion = (int)$pdo->lastInsertId();

    // Persona
    $stmt = $pdo->prepare('INSERT INTO Persona (nombre_persona, apellido_persona, CUIL_persona, telefono_persona, id_direccion)
                           VALUES (?,?,?,?,?)');
    $stmt->execute([$nombre, $apellido, $cuil, $telefono ?: null, $id_direccion]);
    $id_persona = (int)$pdo->lastInsertId();

    // Usuario
    $stmt = $pdo->prepare('UPDATE Usuario SET id_persona = ? WHERE id_usuario = ?');
    $stmt->execute([$id_persona, $userId]);

    $pdo->commit();
    $_SESSION['needs_profile'] = false;

    flash('success', 'La información se ha guardado con éxito.');
    header('Location: index.php');
    exit;

  } catch (Throwable $e) {
    $pdo->rollBack();
    flash('error', 'No se pudo guardar la información.');
    header('Location: index.php?mod=config_usuario');
    exit;
  }
}

/* =========================
   EDICIÓN DE USUARIO (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'usuarios') {

  $form = $_POST['form'] ?? '';

  if ($form === 'edit_usuario') {

    if (!isset($modulosPermitidosConArchivo['usuarios'])) {
      flash('error', 'No tienes permiso para editar usuarios.');
      header('Location: index.php');
      exit;
    }

    $id_usuario     = (int)($_POST['id_usuario'] ?? 0);
    $nombre_usuario = trim($_POST['nombre_usuario'] ?? '');
    $correo_usuario = trim($_POST['correo_usuario'] ?? '');
    $cuil_persona   = trim($_POST['CUIL_persona'] ?? '');
    $id_rol         = (int)($_POST['id_rol'] ?? 0);

    $errores = [];

    if ($id_usuario <= 0) {
      $errores[] = 'ID de usuario inválido.';
    }

    if ($nombre_usuario === '') {
      $errores[] = 'Debe ingresar un nombre de usuario.';
    }

    if ($correo_usuario === '') {
      $errores[] = 'Debe ingresar un correo.';
    }

    if ($correo_usuario !== '' && !filter_var($correo_usuario, FILTER_VALIDATE_EMAIL)) {
      $errores[] = 'Correo inválido.';
    }

    if ($id_rol <= 0) {
      $errores[] = 'Debe seleccionar un perfil válido.';
    }

    if (!$errores) {
      $stmt = $pdo->prepare("
        SELECT id_rol
        FROM Tipo_Rol
        WHERE id_rol = ?
          AND activo = 1
        LIMIT 1
      ");
      $stmt->execute([$id_rol]);

      if (!$stmt->fetch()) {
        $errores[] = 'El perfil seleccionado no existe o está inactivo.';
      }
    }

    /*
      Protección del único administrador:
      si el usuario editado es el único administrador activo del sistema,
      no se permite cambiarlo a otro perfil porque el sistema quedaría
      sin una cuenta con permisos administrativos.
    */
    $rolActualUsuario = 0;
    if (!$errores) {
      $stmt = $pdo->prepare('SELECT id_rol FROM Usuario WHERE id_usuario = ? LIMIT 1');
      $stmt->execute([$id_usuario]);
      $rolActualUsuario = (int)($stmt->fetchColumn() ?: 0);

      if ($rolActualUsuario === 1 && $id_rol !== 1) {
        $stmt = $pdo->query('SELECT COUNT(*) FROM Usuario WHERE id_rol = 1');
        $cantidadAdministradores = (int)$stmt->fetchColumn();

        if ($cantidadAdministradores <= 1) {
          $errores[] = 'No se puede cambiar el perfil del único administrador existente.';
        }
      }
    }

    /*
      Exclusión del propio usuario al editar:
      se valida que no exista OTRO usuario con el mismo usuario/correo/CUIL.
      El usuario que estoy editando queda excluido con AND id_usuario <> ?.
    */

    if (!$errores) {
      $stmt = $pdo->prepare("
        SELECT id_usuario
        FROM Usuario
        WHERE nombre_usuario = ?
        AND id_usuario <> ?
        LIMIT 1
      ");
      $stmt->execute([$nombre_usuario, $id_usuario]);

      if ($stmt->fetch()) {
        $errores[] = 'Ese nombre de usuario ya está en uso.';
      }
    }

    if (!$errores) {
      $stmt = $pdo->prepare("
        SELECT id_usuario
        FROM Usuario
        WHERE correo_usuario = ?
        AND id_usuario <> ?
        LIMIT 1
      ");
      $stmt->execute([$correo_usuario, $id_usuario]);

      if ($stmt->fetch()) {
        $errores[] = 'Ese correo ya está en uso.';
      }
    }

    if (!$errores && $cuil_persona !== '') {
      $stmt = $pdo->prepare("
        SELECT p.id_persona
        FROM Persona p
        INNER JOIN Usuario u ON p.id_persona = u.id_persona
        WHERE p.CUIL_persona = ?
        AND u.id_usuario <> ?
        LIMIT 1
      ");
      $stmt->execute([$cuil_persona, $id_usuario]);

      if ($stmt->fetch()) {
        $errores[] = 'Ese CUIL/DNI ya está registrado.';
      }
    }

    if ($errores) {
      flash('error', implode(' ', $errores));
      header('Location: index.php?mod=usuarios&action=edit&id=' . $id_usuario);
      exit;
    }

    try {
      $pdo->beginTransaction();

      $stmt = $pdo->prepare("
        UPDATE Usuario
        SET nombre_usuario = ?,
            correo_usuario = ?,
            id_rol = ?
        WHERE id_usuario = ?
      ");

      $stmt->execute([
        $nombre_usuario,
        $correo_usuario,
        $id_rol,
        $id_usuario
      ]);

      if ($cuil_persona !== '') {
        $stmt = $pdo->prepare("
          UPDATE Persona p
          INNER JOIN Usuario u ON p.id_persona = u.id_persona
          SET p.CUIL_persona = ?
          WHERE u.id_usuario = ?
        ");

        $stmt->execute([
          $cuil_persona,
          $id_usuario
        ]);
      }

      $pdo->commit();

      /*
        Seguridad de sesión:
        si el administrador edita su propio usuario y cambia su perfil,
        se actualiza la sesión inmediatamente. Así no conserva permisos
        anteriores hasta cerrar e iniciar sesión nuevamente.
      */
      if ($id_usuario === $userId) {
        $_SESSION['auth_user'] = $nombre_usuario;
        $_SESSION['auth_rol'] = $id_rol;

        if ($rolActualUsuario !== $id_rol) {
          flash('success', 'Tu perfil fue actualizado. Los permisos se recalcularon correctamente.');
          header('Location: index.php');
          exit;
        }
      }

      flash('success', 'Usuario actualizado correctamente.');
      header('Location: index.php?mod=usuarios');
      exit;

    } catch (Throwable $e) {
      $pdo->rollBack();

      flash('error', 'No se pudo actualizar el usuario.');
      header('Location: index.php?mod=usuarios&action=edit&id=' . $id_usuario);
      exit;
    }
  }
}


/* =========================
   ABM DE PERFILES / ROLES (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'perfiles') {

  if (!isset($modulosPermitidosConArchivo['perfiles'])) {
    flash('error', 'No tienes permiso para administrar perfiles.');
    header('Location: index.php');
    exit;
  }

  $form = $_POST['form'] ?? '';

  if ($form === 'add_perfil' || $form === 'edit_perfil') {
    $id_rol = (int)($_POST['id_rol'] ?? 0);
    $nombre_rol = trim($_POST['nombre_rol'] ?? '');
    $descripcion_rol = trim($_POST['descripcion_rol'] ?? '');

    $errores = [];

    if ($form === 'edit_perfil' && $id_rol <= 0) {
      $errores[] = 'ID de perfil inválido.';
    }

    if ($nombre_rol === '') {
      $errores[] = 'Debe ingresar el nombre del perfil.';
    }

    if (mb_strlen($nombre_rol) > 50) {
      $errores[] = 'El nombre del perfil no puede superar los 50 caracteres.';
    }

    if (mb_strlen($descripcion_rol) > 100) {
      $errores[] = 'La descripción no puede superar los 100 caracteres.';
    }

    if (!$errores) {
      $sql = 'SELECT id_rol FROM Tipo_Rol WHERE nombre_rol = ?';
      $params = [$nombre_rol];

      if ($form === 'edit_perfil') {
        $sql .= ' AND id_rol <> ?';
        $params[] = $id_rol;
      }

      $sql .= ' LIMIT 1';
      $stmt = $pdo->prepare($sql);
      $stmt->execute($params);

      if ($stmt->fetch()) {
        $errores[] = 'Ya existe un perfil con ese nombre.';
      }
    }

    if ($errores) {
      flash('error', implode(' ', $errores));
      $url = $form === 'edit_perfil'
        ? 'index.php?mod=perfiles&action=edit&id=' . $id_rol
        : 'index.php?mod=perfiles&action=add';
      header('Location: ' . $url);
      exit;
    }

    try {
      $pdo->beginTransaction();

      if ($form === 'add_perfil') {
        $stmt = $pdo->prepare('INSERT INTO Tipo_Rol (nombre_rol, descripcion_rol, activo) VALUES (?, ?, 1)');
        $stmt->execute([$nombre_rol, $descripcion_rol ?: null]);
        $id_rol = (int)$pdo->lastInsertId();
        flash('success', 'Perfil creado correctamente. Ahora puedes asignarle módulos.');
      } else {
        $stmt = $pdo->prepare('UPDATE Tipo_Rol SET nombre_rol = ?, descripcion_rol = ? WHERE id_rol = ?');
        $stmt->execute([$nombre_rol, $descripcion_rol ?: null, $id_rol]);

        $modulosSeleccionados = $_POST['modulos'] ?? [];
        if (!is_array($modulosSeleccionados)) {
          $modulosSeleccionados = [];
        }

        $modulosValidos = [];
        foreach ($modulosSeleccionados as $idModulo) {
          $idModulo = (int)$idModulo;
          if ($idModulo > 0) {
            $modulosValidos[] = $idModulo;
          }
        }
        $modulosValidos = array_values(array_unique($modulosValidos));

        $stmt = $pdo->prepare('DELETE FROM Rol_Modulo WHERE id_rol = ?');
        $stmt->execute([$id_rol]);

        if ($modulosValidos) {
          $stmt = $pdo->prepare('INSERT INTO Rol_Modulo (id_rol, id_modulo) VALUES (?, ?)');
          foreach ($modulosValidos as $idModulo) {
            $stmt->execute([$id_rol, $idModulo]);
          }
        }

        flash('success', 'Perfil actualizado correctamente.');
      }

      $pdo->commit();
      header('Location: index.php?mod=perfiles');
      exit;

    } catch (Throwable $e) {
      if ($pdo->inTransaction()) {
        $pdo->rollBack();
      }
      flash('error', 'No se pudo guardar el perfil. Verifica que existan las tablas Modulo y Rol_Modulo.');
      header('Location: index.php?mod=perfiles');
      exit;
    }
  }


  if ($form === 'activate_perfil') {
    $id_rol = (int)($_POST['id_rol'] ?? 0);

    if ($id_rol <= 0) {
      flash('error', 'ID de perfil inválido.');
      header('Location: index.php?mod=perfiles');
      exit;
    }

    try {
      $stmt = $pdo->prepare('UPDATE Tipo_Rol SET activo = 1 WHERE id_rol = ?');
      $stmt->execute([$id_rol]);

      flash('success', 'Perfil activado correctamente.');
      header('Location: index.php?mod=perfiles');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se pudo activar el perfil.');
      header('Location: index.php?mod=perfiles');
      exit;
    }
  }

  if ($form === 'delete_perfil') {
    $id_rol = (int)($_POST['id_rol'] ?? 0);

    if ($id_rol <= 0) {
      flash('error', 'ID de perfil inválido.');
      header('Location: index.php?mod=perfiles');
      exit;
    }

    if ($id_rol === 1) {
      flash('error', 'No se puede desactivar el perfil Administrador principal.');
      header('Location: index.php?mod=perfiles');
      exit;
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM Usuario WHERE id_rol = ?');
    $stmt->execute([$id_rol]);
    $usuariosConPerfil = (int)$stmt->fetchColumn();

    if ($usuariosConPerfil > 0) {
      flash('error', 'No se puede desactivar el perfil porque hay usuarios asignados.');
      header('Location: index.php?mod=perfiles');
      exit;
    }

    try {
      $stmt = $pdo->prepare('UPDATE Tipo_Rol SET activo = 0 WHERE id_rol = ?');
      $stmt->execute([$id_rol]);

      flash('success', 'Perfil desactivado correctamente.');
      header('Location: index.php?mod=perfiles');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se pudo desactivar el perfil.');
      header('Location: index.php?mod=perfiles');
      exit;
    }
  }
}

/* =========================
   ALTA / EDICIÓN / ELIMINACIÓN PRODUCTO (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'productos') {

  $form = $_POST['form'] ?? '';

  if ($form === 'add_producto') {
    $nombre_prod  = trim($_POST['nombre_producto'] ?? '');
    $precio_prod  = trim($_POST['precio_producto'] ?? '');
    $stock_prod   = trim($_POST['stock_producto'] ?? '');
    $id_categoria = $_POST['id_categoria'] ?? '';
    $id_proveedor = $_POST['id_proveedor'] ?? '';

    $errores = [];
    if ($nombre_prod === '')                               $errores[] = 'Falta el nombre del producto.';
    if ($precio_prod === '')                               $errores[] = 'Falta el precio del producto.';
    if ($stock_prod === '')                                $errores[] = 'Falta el stock del producto.';
    if (!is_numeric($precio_prod) || $precio_prod < 0)     $errores[] = 'El precio no es válido.';
    if (!ctype_digit($stock_prod) || (int)$stock_prod < 0) $errores[] = 'El stock no es válido.';
    if ($id_categoria === '')                              $errores[] = 'Debe seleccionar una categoría.';
    if ($id_proveedor === '')                              $errores[] = 'Debe seleccionar un proveedor.';

    if ($errores) {
      flash('error', implode(' ', $errores));
      header('Location: index.php?mod=productos&action=add');
      exit;
    }

    try {
      $stmt = $pdo->prepare('INSERT INTO Producto (nombre_producto, precio_producto, stock_producto, id_categoria, id_proveedor)
                             VALUES (?,?,?,?,?)');
      $stmt->execute([
        $nombre_prod,
        (float)$precio_prod,
        (int)$stock_prod,
        (int)$id_categoria,
        (int)$id_proveedor
      ]);

      flash('success', 'El producto se ha agregado correctamente.');
      header('Location: index.php?mod=productos');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se pudo agregar el producto. Inténtalo nuevamente.');
      header('Location: index.php?mod=productos&action=add');
      exit;
    }

  } elseif ($form === 'edit_producto') {

    $id_producto  = (int)($_POST['id_producto'] ?? 0);
    $nombre_prod  = trim($_POST['nombre_producto'] ?? '');
    $precio_prod  = trim($_POST['precio_producto'] ?? '');
    $stock_prod   = trim($_POST['stock_producto'] ?? '');
    $id_categoria = $_POST['id_categoria'] ?? '';
    $id_proveedor = $_POST['id_proveedor'] ?? '';

    $errores = [];
    if ($id_producto <= 0)                                 $errores[] = 'ID de producto inválido.';
    if ($nombre_prod === '')                               $errores[] = 'Falta el nombre del producto.';
    if ($precio_prod === '')                               $errores[] = 'Falta el precio del producto.';
    if ($stock_prod === '')                                $errores[] = 'Falta el stock del producto.';
    if (!is_numeric($precio_prod) || $precio_prod < 0)     $errores[] = 'El precio no es válido.';
    if (!ctype_digit($stock_prod) || (int)$stock_prod < 0) $errores[] = 'El stock no es válido.';
    if ($id_categoria === '')                              $errores[] = 'Debe seleccionar una categoría.';
    if ($id_proveedor === '')                              $errores[] = 'Debe seleccionar un proveedor.';

    if ($errores) {
      flash('error', implode(' ', $errores));
      header('Location: index.php?mod=productos&action=edit&id=' . $id_producto);
      exit;
    }

    try {
      $stmt = $pdo->prepare('UPDATE Producto
                             SET nombre_producto = ?, precio_producto = ?, stock_producto = ?,
                                 id_categoria = ?, id_proveedor = ?
                             WHERE id_producto = ?');
      $stmt->execute([
        $nombre_prod,
        (float)$precio_prod,
        (int)$stock_prod,
        (int)$id_categoria,
        (int)$id_proveedor,
        $id_producto
      ]);

      flash('success', 'El producto se ha actualizado correctamente.');
      header('Location: index.php?mod=productos');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se pudo actualizar el producto.');
      header('Location: index.php?mod=productos&action=edit&id=' . $id_producto);
      exit;
    }

  } elseif ($form === 'delete_producto') {

    $id_producto = (int)($_POST['id_producto'] ?? 0);

    if ($id_producto <= 0) {
      flash('error', 'ID de producto inválido.');
      header('Location: index.php?mod=productos');
      exit;
    }

    try {
      $stmt = $pdo->prepare('DELETE FROM Producto WHERE id_producto = ?');
      $stmt->execute([$id_producto]);

      if ($stmt->rowCount() > 0) {
        flash('success', 'El producto se eliminó correctamente.');
      } else {
        flash('error', 'No se encontró el producto a eliminar.');
      }

      header('Location: index.php?mod=productos');
      exit;

    } catch (Throwable $e) {
      flash('error', 'No se puede eliminar el producto porque está relacionado con otros registros.');
      header('Location: index.php?mod=productos');
      exit;
    }
  }
}

/* =========================
   REGISTRAR MOVIMIENTO (POST)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $modActual === 'movimientos') {

  $form = $_POST['form'] ?? '';

  if ($form === 'add_movimiento') {

    $id_producto = (int)($_POST['id_producto'] ?? 0);
    $id_tipo     = (int)($_POST['id_tipo'] ?? 0);
    $id_motivo   = (int)($_POST['id_motivo'] ?? 0);
    $cantidad    = trim($_POST['cantidad_movimiento'] ?? '');

    $errores = [];
    if ($id_producto <= 0)                  $errores[] = 'Debe seleccionar un producto.';
    if ($id_tipo <= 0)                      $errores[] = 'Debe seleccionar un tipo de movimiento.';
    if ($id_motivo <= 0)                    $errores[] = 'Debe seleccionar un motivo.';
    if ($cantidad === '' || !ctype_digit($cantidad) || (int)$cantidad <= 0) {
      $errores[] = 'La cantidad debe ser un entero positivo.';
    }

    if ($errores) {
      flash('error', implode(' ', $errores));
      header('Location: index.php?mod=movimientos&action=add');
      exit;
    }

    $cantidadInt = (int)$cantidad;

    try {
      $pdo->beginTransaction();

      // Traer stock actual del producto
      $stmt = $pdo->prepare("SELECT stock_producto FROM Producto WHERE id_producto = ?");
      $stmt->execute([$id_producto]);
      $prod = $stmt->fetch();

      if (!$prod) {
        $pdo->rollBack();
        flash('error', 'Producto no encontrado.');
        header('Location: index.php?mod=movimientos&action=add');
        exit;
      }

      $stockActual = (int)$prod['stock_producto'];

      // Convención:
      // id_tipo = 1 => Entrada (suma stock)
      // id_tipo = 2 => Salida (resta stock)
      $delta = 0;

      if ($id_tipo === 1) {
        $delta = $cantidadInt; // Entrada
      } elseif ($id_tipo === 2) {
        if ($stockActual < $cantidadInt) {
          $pdo->rollBack();
          flash('error', 'No hay stock suficiente para realizar la salida.');
          header('Location: index.php?mod=movimientos&action=add');
          exit;
        }
        $delta = -$cantidadInt;
      } else {
        $delta = 0; // otros tipos sin impacto en stock
      }

      // Insertar movimiento
      $stmt = $pdo->prepare("INSERT INTO Movimiento
        (cantidad_movimiento, fecha_movimiento, id_producto, id_usuario, id_tipo, id_motivo)
        VALUES (?, NOW(), ?, ?, ?, ?)");
      $stmt->execute([
        $cantidadInt,
        $id_producto,
        $userId,
        $id_tipo,
        $id_motivo
      ]);

      // Actualizar stock si corresponde
      if ($delta !== 0) {
        $stmt = $pdo->prepare("UPDATE Producto SET stock_producto = stock_producto + ? WHERE id_producto = ?");
        $stmt->execute([$delta, $id_producto]);
      }

      $pdo->commit();

      flash('success', 'El movimiento se registró correctamente.');
      header('Location: index.php?mod=movimientos');
      exit;

    } catch (Throwable $e) {
      $pdo->rollBack();
      flash('error', 'No se pudo registrar el movimiento.');
      header('Location: index.php?mod=movimientos&action=add');
      exit;
    }
  }
}

